# SEO checklist

The page title must stay exactly as it is. Preserve the existing visual design.

## Implemented locally (publish and verify on the live host)

- [x] 2. Self-referencing canonical: https://ramazanbayborek.com/
- [x] 4. Open Graph and Twitter Card metadata using the existing portrait.
- [x] 5. robots.txt allowing crawling and declaring the sitemap.
- [x] 6. sitemap.xml containing the single public homepage.
- [x] 7. Heading hierarchy: one H1, section H2s, subsection H3s; retain existing typography.

## Remaining items — keep the original numbering

- [x] 1. Refined the meta description and kept the title.
- [x] 3. Added ProfilePage / Person structured data.
- [ ] 8. Deploy and verify the prepared canonical 301 redirects in .htaccess.
- [ ] 9. Search Console ownership and homepage indexing confirmed. Submit the sitemap after publishing and review search performance.
- [x] 10. Completed the first local mobile performance pass, including before/after LCP and CLS measurements.

When the user says "kalan listeden devam edelim", present the remaining items above before proceeding. No commit or deployment was requested.
